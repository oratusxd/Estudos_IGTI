// Tipos primitivos
var vNumber = 5.78;
var vString = 'abacaxi';
var vBoolean = true;
