
var mensagem = 'Olá';
mensagem = 'Olá Danilo';

console.log(mensagem); // comentário

// comentário de uma linha
// comentário de uma linha

/*

comentário

console.log(mensagem);

*/