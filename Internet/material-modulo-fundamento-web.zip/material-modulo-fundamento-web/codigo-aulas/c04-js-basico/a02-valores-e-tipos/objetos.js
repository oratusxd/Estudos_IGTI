// Objetos

var aluno1 = {
  matricula: 7627364,
  nome: 'Danilo Ferreira',
  curso: 'Bootcamp Front End',
  ativo: true
};

console.log(aluno1.nome);

aluno1.dataNascimento = '03/07/1985';
console.log(aluno1.dataNascimento);

delete aluno1.dataNascimento;

// Undefined e null

var x;
var y = null;

// Arrays

var frutas = ['Banana', 'Laranja', 'Maçã'];