import * as m1 from "./modulo1.js";

m1.soma(m1.PI, 2);
